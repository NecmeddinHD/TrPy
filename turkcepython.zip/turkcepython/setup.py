from setuptools import setup

setup{
    name='TrPy',
    version='0.2',
    license='',
    url=''
    author='NecmeddinHD'


}