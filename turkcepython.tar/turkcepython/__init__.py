import trpy
version = 0.2
hellomsg ='TrPy InterPrinter a hoş geldiniz TrPY bağımsız bir projedir'