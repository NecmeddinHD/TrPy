import trpy
from trpy import yazdir
from trpy import giris
from trpy import eger
import __init__

print(__init__.hellomsg)
print('V'+str(__init__.version))

def help(komut):
    if (komut=="yazdir"):
        print('Kullanım : "yazdir(YAZI)" YAZI yı tırnak içinde yazın')
        print('İşleyiş : "Ekrana YAZI yazdırır"')
        print('Alternatif : "print(YAZI)" YAZI tırnak içinde')
    elif(komut == "giris"):
        print('Kullanım : "giris(YAZI)" YAZI tırnak içinde')
        print('İşleyiş : "Kullanıcıdan giriş alır ve kullanmanızı sağlar Not: YAZI giroş alırken kullanılacak yazıyı belirler zorunlu değildir"')
        print()
        print('Alternatif : "input(YAZI)" YAZI tırnak içinde')
    elif(komut=="eger"):
        print('Kullanım : "eger(KOŞUL,SONUÇ)" KOŞUL ve SONUÇ tırnak içinde ikiside zoruludur')
        print()
        print('Örnek : "eger("degisken > 1","yazdir("1 den büyük")""')
        print()
        print('Açıklama : Örnekte değişken bir den büyükse sonuç veriyor')
        print('İşleyiş : "eğer verilen koşul doğru ise sonuç kodu çalışır"')
        print('Alternatif : "if (degisken > 1): print("Bir den büyük")"')
    elif(komut==""):
        print('Komutlar :')
        print('yazdir(yazi)')
        print('giris(yazi)')
        print('eger(kosul,sonuc)')
while True:
    print()
    giris = input("trpy>>> ")
    if(giris=='help'):
        print('Komutlar :')
        print('yazdir(yazi)')
        print('giris(yazi)')
        print('eger(kosul,sonuc)')
    else:    
        exec(giris)